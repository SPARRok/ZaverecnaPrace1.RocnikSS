﻿namespace $rootnamespace$
{
    partial class $safeitemname$
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.předmětyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programováníToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inicializaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deklaraceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matematikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elektrotechnikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ohmůvZákonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kirchoffůvZákonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.angličtinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informačníAKomunikačníTechnologieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.českýJazykToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fyzikaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kalkulačkyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matematikaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.základyElektrotechnikyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ohmůvZákonToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vypocetNapětíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vypočetProuduIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vypočetOdporuRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fyzikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jinéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.převodJednotekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.odejítToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nastaveníToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.coToJeDátovyTypToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coToJeProměnnáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chybyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programovacíJazykyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zajímavostiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hardwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.softwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historickéObdobiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pravopisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.magnetyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gramatikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.presentSimpleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.přestávkaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bullsAndCowsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jinéToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mbitsDoMBsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.předmětyToolStripMenuItem,
            this.kalkulačkyToolStripMenuItem,
            this.převodJednotekToolStripMenuItem,
            this.přestávkaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(123, 621);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // předmětyToolStripMenuItem
            // 
            this.předmětyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programováníToolStripMenuItem,
            this.matematikaToolStripMenuItem,
            this.elektrotechnikaToolStripMenuItem,
            this.angličtinaToolStripMenuItem,
            this.informačníAKomunikačníTechnologieToolStripMenuItem,
            this.českýJazykToolStripMenuItem,
            this.fyzikaToolStripMenuItem1});
            this.předmětyToolStripMenuItem.Name = "předmětyToolStripMenuItem";
            this.předmětyToolStripMenuItem.Size = new System.Drawing.Size(141, 33);
            this.předmětyToolStripMenuItem.Text = "Předměty";
            // 
            // programováníToolStripMenuItem
            // 
            this.programováníToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.coToJeDátovyTypToolStripMenuItem,
            this.coToJeProměnnáToolStripMenuItem,
            this.chybyToolStripMenuItem,
            this.inicializaceToolStripMenuItem,
            this.deklaraceToolStripMenuItem,
            this.programovacíJazykyToolStripMenuItem,
            this.zajímavostiToolStripMenuItem});
            this.programováníToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.programováníToolStripMenuItem.Name = "programováníToolStripMenuItem";
            this.programováníToolStripMenuItem.Size = new System.Drawing.Size(329, 28);
            this.programováníToolStripMenuItem.Text = "Programování";
            // 
            // inicializaceToolStripMenuItem
            // 
            this.inicializaceToolStripMenuItem.Name = "inicializaceToolStripMenuItem";
            this.inicializaceToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.inicializaceToolStripMenuItem.Text = "Inicializace a deklarace";
            // 
            // deklaraceToolStripMenuItem
            // 
            this.deklaraceToolStripMenuItem.Name = "deklaraceToolStripMenuItem";
            this.deklaraceToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.deklaraceToolStripMenuItem.Text = "Inkrementace / dekrementace";
            // 
            // matematikaToolStripMenuItem
            // 
            this.matematikaToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.matematikaToolStripMenuItem.Name = "matematikaToolStripMenuItem";
            this.matematikaToolStripMenuItem.Size = new System.Drawing.Size(329, 28);
            this.matematikaToolStripMenuItem.Text = "Matematika";
            // 
            // elektrotechnikaToolStripMenuItem
            // 
            this.elektrotechnikaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ohmůvZákonToolStripMenuItem,
            this.kirchoffůvZákonToolStripMenuItem,
            this.magnetyToolStripMenuItem});
            this.elektrotechnikaToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.elektrotechnikaToolStripMenuItem.Name = "elektrotechnikaToolStripMenuItem";
            this.elektrotechnikaToolStripMenuItem.Size = new System.Drawing.Size(329, 28);
            this.elektrotechnikaToolStripMenuItem.Text = "Elektrotechnika";
            this.elektrotechnikaToolStripMenuItem.Click += new System.EventHandler(this.elektrotechnikaToolStripMenuItem_Click);
            // 
            // ohmůvZákonToolStripMenuItem
            // 
            this.ohmůvZákonToolStripMenuItem.Name = "ohmůvZákonToolStripMenuItem";
            this.ohmůvZákonToolStripMenuItem.Size = new System.Drawing.Size(192, 28);
            this.ohmůvZákonToolStripMenuItem.Text = "Ohmův zákon";
            // 
            // kirchoffůvZákonToolStripMenuItem
            // 
            this.kirchoffůvZákonToolStripMenuItem.Name = "kirchoffůvZákonToolStripMenuItem";
            this.kirchoffůvZákonToolStripMenuItem.Size = new System.Drawing.Size(192, 28);
            this.kirchoffůvZákonToolStripMenuItem.Text = "Kirchoffův zákon";
            // 
            // angličtinaToolStripMenuItem
            // 
            this.angličtinaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gramatikaToolStripMenuItem});
            this.angličtinaToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.angličtinaToolStripMenuItem.Name = "angličtinaToolStripMenuItem";
            this.angličtinaToolStripMenuItem.Size = new System.Drawing.Size(329, 28);
            this.angličtinaToolStripMenuItem.Text = "Anglický jazyk";
            // 
            // informačníAKomunikačníTechnologieToolStripMenuItem
            // 
            this.informačníAKomunikačníTechnologieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hardwareToolStripMenuItem,
            this.softwareToolStripMenuItem});
            this.informačníAKomunikačníTechnologieToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.informačníAKomunikačníTechnologieToolStripMenuItem.Name = "informačníAKomunikačníTechnologieToolStripMenuItem";
            this.informačníAKomunikačníTechnologieToolStripMenuItem.Size = new System.Drawing.Size(329, 28);
            this.informačníAKomunikačníTechnologieToolStripMenuItem.Text = "Informační a komunikační technologie";
            // 
            // českýJazykToolStripMenuItem
            // 
            this.českýJazykToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.historickéObdobiToolStripMenuItem,
            this.pravopisToolStripMenuItem});
            this.českýJazykToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.českýJazykToolStripMenuItem.Name = "českýJazykToolStripMenuItem";
            this.českýJazykToolStripMenuItem.Size = new System.Drawing.Size(329, 28);
            this.českýJazykToolStripMenuItem.Text = "Český jazyk";
            // 
            // fyzikaToolStripMenuItem1
            // 
            this.fyzikaToolStripMenuItem1.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F);
            this.fyzikaToolStripMenuItem1.Name = "fyzikaToolStripMenuItem1";
            this.fyzikaToolStripMenuItem1.Size = new System.Drawing.Size(329, 28);
            this.fyzikaToolStripMenuItem1.Text = "Fyzika";
            // 
            // kalkulačkyToolStripMenuItem
            // 
            this.kalkulačkyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.matematikaToolStripMenuItem1,
            this.základyElektrotechnikyToolStripMenuItem,
            this.fyzikaToolStripMenuItem,
            this.jinéToolStripMenuItem});
            this.kalkulačkyToolStripMenuItem.Name = "kalkulačkyToolStripMenuItem";
            this.kalkulačkyToolStripMenuItem.Size = new System.Drawing.Size(141, 33);
            this.kalkulačkyToolStripMenuItem.Text = "Kalkulačky";
            // 
            // matematikaToolStripMenuItem1
            // 
            this.matematikaToolStripMenuItem1.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F);
            this.matematikaToolStripMenuItem1.Name = "matematikaToolStripMenuItem1";
            this.matematikaToolStripMenuItem1.Size = new System.Drawing.Size(188, 28);
            this.matematikaToolStripMenuItem1.Text = "Matematika";
            // 
            // základyElektrotechnikyToolStripMenuItem
            // 
            this.základyElektrotechnikyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ohmůvZákonToolStripMenuItem1});
            this.základyElektrotechnikyToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F);
            this.základyElektrotechnikyToolStripMenuItem.Name = "základyElektrotechnikyToolStripMenuItem";
            this.základyElektrotechnikyToolStripMenuItem.Size = new System.Drawing.Size(188, 28);
            this.základyElektrotechnikyToolStripMenuItem.Text = "Elektrotechnika";
            // 
            // ohmůvZákonToolStripMenuItem1
            // 
            this.ohmůvZákonToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vypocetNapětíToolStripMenuItem,
            this.vypočetProuduIToolStripMenuItem,
            this.vypočetOdporuRToolStripMenuItem});
            this.ohmůvZákonToolStripMenuItem1.Name = "ohmůvZákonToolStripMenuItem1";
            this.ohmůvZákonToolStripMenuItem1.Size = new System.Drawing.Size(171, 28);
            this.ohmůvZákonToolStripMenuItem1.Text = "Ohmův zákon";
            // 
            // vypocetNapětíToolStripMenuItem
            // 
            this.vypocetNapětíToolStripMenuItem.Name = "vypocetNapětíToolStripMenuItem";
            this.vypocetNapětíToolStripMenuItem.Size = new System.Drawing.Size(201, 28);
            this.vypocetNapětíToolStripMenuItem.Text = "Vypocet napětí (U)";
            // 
            // vypočetProuduIToolStripMenuItem
            // 
            this.vypočetProuduIToolStripMenuItem.Name = "vypočetProuduIToolStripMenuItem";
            this.vypočetProuduIToolStripMenuItem.Size = new System.Drawing.Size(201, 28);
            this.vypočetProuduIToolStripMenuItem.Text = "Vypočet proudu (I)";
            // 
            // vypočetOdporuRToolStripMenuItem
            // 
            this.vypočetOdporuRToolStripMenuItem.Name = "vypočetOdporuRToolStripMenuItem";
            this.vypočetOdporuRToolStripMenuItem.Size = new System.Drawing.Size(201, 28);
            this.vypočetOdporuRToolStripMenuItem.Text = "Vypočet odporu (R)";
            // 
            // fyzikaToolStripMenuItem
            // 
            this.fyzikaToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F);
            this.fyzikaToolStripMenuItem.Name = "fyzikaToolStripMenuItem";
            this.fyzikaToolStripMenuItem.Size = new System.Drawing.Size(188, 28);
            this.fyzikaToolStripMenuItem.Text = "Fyzika";
            // 
            // jinéToolStripMenuItem
            // 
            this.jinéToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F);
            this.jinéToolStripMenuItem.Name = "jinéToolStripMenuItem";
            this.jinéToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.jinéToolStripMenuItem.Text = "Jiné";
            // 
            // převodJednotekToolStripMenuItem
            // 
            this.převodJednotekToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.jinéToolStripMenuItem1});
            this.převodJednotekToolStripMenuItem.Name = "převodJednotekToolStripMenuItem";
            this.převodJednotekToolStripMenuItem.Size = new System.Drawing.Size(141, 33);
            this.převodJednotekToolStripMenuItem.Text = "Převod";
            this.převodJednotekToolStripMenuItem.Click += new System.EventHandler(this.PřevodJednotekToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(123, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(946, 12);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(183, 11);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(216, 123);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(49, 53);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "by Mykyta Vorobiov";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(79, 80);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 33);
            this.label3.TabIndex = 2;
            this.label3.Text = "T1.A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(16, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 33);
            this.label1.TabIndex = 2;
            this.label1.Text = "Výuková aplikace";
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.menuStrip2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.odejítToolStripMenuItem,
            this.nastaveníToolStripMenuItem1,
            this.infoToolStripMenuItem1});
            this.menuStrip2.Location = new System.Drawing.Point(0, 621);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip2.Size = new System.Drawing.Size(1069, 37);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // odejítToolStripMenuItem
            // 
            this.odejítToolStripMenuItem.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odejítToolStripMenuItem.Name = "odejítToolStripMenuItem";
            this.odejítToolStripMenuItem.Size = new System.Drawing.Size(71, 33);
            this.odejítToolStripMenuItem.Text = "Odejít";
            this.odejítToolStripMenuItem.Click += new System.EventHandler(this.odejítToolStripMenuItem_Click);
            // 
            // nastaveníToolStripMenuItem1
            // 
            this.nastaveníToolStripMenuItem1.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.nastaveníToolStripMenuItem1.Name = "nastaveníToolStripMenuItem1";
            this.nastaveníToolStripMenuItem1.Size = new System.Drawing.Size(104, 33);
            this.nastaveníToolStripMenuItem1.Text = "Nastavení";
            // 
            // infoToolStripMenuItem1
            // 
            this.infoToolStripMenuItem1.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.infoToolStripMenuItem1.Name = "infoToolStripMenuItem1";
            this.infoToolStripMenuItem1.Size = new System.Drawing.Size(55, 33);
            this.infoToolStripMenuItem1.Text = "Info";
            this.infoToolStripMenuItem1.Click += new System.EventHandler(this.infoToolStripMenuItem1_Click);
            // 
            // coToJeDátovyTypToolStripMenuItem
            // 
            this.coToJeDátovyTypToolStripMenuItem.Name = "coToJeDátovyTypToolStripMenuItem";
            this.coToJeDátovyTypToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.coToJeDátovyTypToolStripMenuItem.Text = "Co to je dátovy typ";
            this.coToJeDátovyTypToolStripMenuItem.Click += new System.EventHandler(this.CoToJeDátovyTypToolStripMenuItem_Click);
            // 
            // coToJeProměnnáToolStripMenuItem
            // 
            this.coToJeProměnnáToolStripMenuItem.Name = "coToJeProměnnáToolStripMenuItem";
            this.coToJeProměnnáToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.coToJeProměnnáToolStripMenuItem.Text = "Co to je proměnná";
            // 
            // chybyToolStripMenuItem
            // 
            this.chybyToolStripMenuItem.Name = "chybyToolStripMenuItem";
            this.chybyToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.chybyToolStripMenuItem.Text = "Chyby";
            // 
            // programovacíJazykyToolStripMenuItem
            // 
            this.programovacíJazykyToolStripMenuItem.Name = "programovacíJazykyToolStripMenuItem";
            this.programovacíJazykyToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.programovacíJazykyToolStripMenuItem.Text = "Programovací jazyky";
            // 
            // zajímavostiToolStripMenuItem
            // 
            this.zajímavostiToolStripMenuItem.Name = "zajímavostiToolStripMenuItem";
            this.zajímavostiToolStripMenuItem.Size = new System.Drawing.Size(274, 28);
            this.zajímavostiToolStripMenuItem.Text = "Zajímavosti";
            // 
            // hardwareToolStripMenuItem
            // 
            this.hardwareToolStripMenuItem.Name = "hardwareToolStripMenuItem";
            this.hardwareToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.hardwareToolStripMenuItem.Text = "Hardware";
            // 
            // softwareToolStripMenuItem
            // 
            this.softwareToolStripMenuItem.Name = "softwareToolStripMenuItem";
            this.softwareToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.softwareToolStripMenuItem.Text = "Software";
            // 
            // historickéObdobiToolStripMenuItem
            // 
            this.historickéObdobiToolStripMenuItem.Name = "historickéObdobiToolStripMenuItem";
            this.historickéObdobiToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.historickéObdobiToolStripMenuItem.Text = "Historické obdobi";
            // 
            // pravopisToolStripMenuItem
            // 
            this.pravopisToolStripMenuItem.Name = "pravopisToolStripMenuItem";
            this.pravopisToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.pravopisToolStripMenuItem.Text = "Pravopis";
            // 
            // magnetyToolStripMenuItem
            // 
            this.magnetyToolStripMenuItem.Name = "magnetyToolStripMenuItem";
            this.magnetyToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.magnetyToolStripMenuItem.Text = "Magnety";
            // 
            // gramatikaToolStripMenuItem
            // 
            this.gramatikaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.presentSimpleToolStripMenuItem});
            this.gramatikaToolStripMenuItem.Name = "gramatikaToolStripMenuItem";
            this.gramatikaToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.gramatikaToolStripMenuItem.Text = "Gramatika";
            // 
            // presentSimpleToolStripMenuItem
            // 
            this.presentSimpleToolStripMenuItem.Name = "presentSimpleToolStripMenuItem";
            this.presentSimpleToolStripMenuItem.Size = new System.Drawing.Size(216, 28);
            this.presentSimpleToolStripMenuItem.Text = "Present Simple";
            // 
            // přestávkaToolStripMenuItem
            // 
            this.přestávkaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bullsAndCowsToolStripMenuItem});
            this.přestávkaToolStripMenuItem.Name = "přestávkaToolStripMenuItem";
            this.přestávkaToolStripMenuItem.Size = new System.Drawing.Size(141, 33);
            this.přestávkaToolStripMenuItem.Text = "Přestávka";
            // 
            // bullsAndCowsToolStripMenuItem
            // 
            this.bullsAndCowsToolStripMenuItem.Name = "bullsAndCowsToolStripMenuItem";
            this.bullsAndCowsToolStripMenuItem.Size = new System.Drawing.Size(216, 34);
            this.bullsAndCowsToolStripMenuItem.Text = "Bulls and cows";
            // 
            // jinéToolStripMenuItem1
            // 
            this.jinéToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mbitsDoMBsToolStripMenuItem1});
            this.jinéToolStripMenuItem1.Name = "jinéToolStripMenuItem1";
            this.jinéToolStripMenuItem1.Size = new System.Drawing.Size(216, 34);
            this.jinéToolStripMenuItem1.Text = "Jiné";
            // 
            // mbitsDoMBsToolStripMenuItem1
            // 
            this.mbitsDoMBsToolStripMenuItem1.Name = "mbitsDoMBsToolStripMenuItem1";
            this.mbitsDoMBsToolStripMenuItem1.Size = new System.Drawing.Size(216, 34);
            this.mbitsDoMBsToolStripMenuItem1.Text = "Mbit/s do MB/s";
            // 
            // $safeitemname$
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1069, 658);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "$safeitemname$";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "$safeitemname$";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
//        private System.Windows.Forms.ToolStripMenuItem Menu;
        private System.Windows.Forms.ToolStripMenuItem předmětyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kalkulačkyToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem programováníToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matematikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem elektrotechnikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem angličtinaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informačníAKomunikačníTechnologieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem českýJazykToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem odejítToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nastaveníToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ohmůvZákonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kirchoffůvZákonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matematikaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem základyElektrotechnikyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fyzikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inicializaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deklaraceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fyzikaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ohmůvZákonToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vypocetNapětíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vypočetProuduIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vypočetOdporuRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jinéToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem převodJednotekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coToJeDátovyTypToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coToJeProměnnáToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chybyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programovacíJazykyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zajímavostiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hardwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem softwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem magnetyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gramatikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem presentSimpleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historickéObdobiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pravopisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jinéToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem přestávkaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bullsAndCowsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mbitsDoMBsToolStripMenuItem1;
    }
}

